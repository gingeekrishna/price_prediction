# Vehicle Market Data Price Prediction Starter Repo

This project contains starter code and data for vehicle price prediction using historical vehicle data and market trends.

## Structure

- `data/` - sample CSV data files for historical vehicle info and market data
- `notebooks/` - exploratory data analysis and model training notebooks (to be added)
- `src/` - Python modules for data loading, model, agent logic, and prediction
- `.env.sample` - sample environment variables for API keys or secrets
- `requirements.txt` - required Python packages

## How to use

1. Create a virtual environment and install requirements:

```
python -m venv venv
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate   # Windows
pip install -r requirements.txt
python3 -m src.demo_agent 
```

2. Rename `.env.sample` to `.env` and add your API keys if needed.

3. Explore data and train models using the notebooks or `src` scripts.

4. Extend the agent logic for integrating market data and advanced AI features.

5. Restart the environment

```
deactivate
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate   # Windows
pip install -r requirements.txt
python3 -m src.demo_agent 
```
6. To run the API use the below command

```
uvicorn src.api:app --reload
```

7. Run the below command to expose the API instead of localhost

```
uvicorn src.api:app --host 0.0.0.0 --port 8000 --reload
```

8. For expose the API publick 

```
cmd : brew install ngrok
singup in  https://dashboard.ngrok.com/signup
cmd : ngrok config add-authtoken 30QgTRA1Ixs5PHMwspRl8NQmmzi_3QjLrN1SbGi3QXaTgSBmx
cmd : ngrok http 8000
```

9. To Run locally with python server

```
python3 -m http.server
```

10. To update the requirement.txt

```
pip freeze > requirements.txt
```

11. train the model 

```
python scripts/train_model.py
```

12. set the environment variable for openAPI Key

```
export OPENAI_API_KEY="your_api_key_here"
```

13. Creating the docker file

```
docker build -t vehicle-price-agent .
```

14. Run the docker file

```
docker run -p 8000:8000 vehicle-price-agent
```