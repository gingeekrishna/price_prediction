import os
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

def load_historical_data(path="data/historical_vehicle_data.csv"):
    return pd.read_csv(path)

def load_market_data(path="data/market_trends.csv"):
    # In real scenario, replace this with API call using secure API key from env vars
    api_key = os.getenv("MARKET_API_KEY")
    # dummy example: market_df = call_market_api(api_key)
    market_df = pd.read_csv(path)
    return market_df

def merge_data():
    hist_df = load_historical_data()
    market_df = load_market_data()
    # Merge on date or relevant keys
    merged_df = pd.merge(hist_df, market_df, on="date", how="left")
    return merged_df
