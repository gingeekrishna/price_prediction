import random

class MarketAgent:
    def get_market_data(self):
        # Simulate market data (replace with real API later)
        return {
            "market_index": round(random.uniform(1000, 1200), 2),
            "fuel_price": round(random.uniform(3.0, 4.5), 2)
        }
