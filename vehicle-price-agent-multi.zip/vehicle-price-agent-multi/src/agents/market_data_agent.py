# src/agents/market_data_agent.py

class MarketDataAgent:
    def fetch(self):
        # Mock or plug in real API logic
        return {
            "market_index": 1120.5,
            "fuel_price": 3.75
        }
