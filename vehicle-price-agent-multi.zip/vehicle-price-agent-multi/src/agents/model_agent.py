import pickle
import pandas as pd

class PriceModelAgent:
    def __init__(self, model_path="src/model.pkl"):
        with open(model_path, "rb") as f:
            self.model = pickle.load(f)

    def predict(self, input_data: dict):
        df = pd.DataFrame([input_data])
        return self.model.predict(df)[0]
