import pandas as pd

class VehiclePriceAgent:
    def __init__(self, model, feature_names):
        self.model = model
        self.feature_names = feature_names

    def perceive(self, vehicle_data, market_data):
        combined = {**vehicle_data, **market_data}
        filtered = {key: combined.get(key, 0) for key in self.feature_names}  # fill missing with 0
        df = pd.DataFrame([filtered])
        return df

    def decide(self, processed_input):
        print("Processed input:")
        print(processed_input)
        print("Input columns:", processed_input.columns.tolist())
        try:
            print("Model expects:", list(self.model.feature_names_in_))
        except AttributeError:
            print("Warning: model.feature_names_in_ not available")

        prediction = self.model.predict(processed_input)[0]
        return prediction

    def act(self, prediction):
        return f"Recommended price: ${prediction:,.2f}"

    def run(self, vehicle_data, market_data):
        processed = self.perceive(vehicle_data, market_data)
        decision = self.decide(processed)
        action = self.act(decision)
        return action
