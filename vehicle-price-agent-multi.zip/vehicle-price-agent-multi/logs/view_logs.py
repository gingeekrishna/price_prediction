import sqlite3

conn = sqlite3.connect('predictions.db')
cursor = conn.cursor()
cursor.execute('SELECT * FROM predictions ORDER BY timestamp DESC')
rows = cursor.fetchall()
for row in rows:
    print(row)
conn.close()